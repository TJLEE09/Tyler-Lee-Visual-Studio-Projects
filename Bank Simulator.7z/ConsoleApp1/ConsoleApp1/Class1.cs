﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Compte // class voiture
    {
        public string prenom { get; set; }
        public string nom { get; set; }
        public int numcompte { get; set; }
        public int solde { get; set; }

        public Compte (string prenom, string nom, int numcompte, int solde)
        {
            this.prenom = prenom;
            this.nom = nom;
            this.numcompte = numcompte;
            this.solde = solde;
            solde = 500;
        }

        public void Info()
        {
            Console.WriteLine("Prenom: " + prenom);
            Console.WriteLine("Nom: " + nom);
            Console.WriteLine("Nombre de compte: " + numcompte);
            Console.WriteLine("Le solde: " + solde +"$");

        }

        public void Virement(int add)
        {
          solde += add; // ajouter add a solde
            Console.WriteLine("Ton solde est: "+ solde +"$");
        }

        public void Retrait(int minus)
        {
            if (minus > solde) // si minus est plus grand que solde cest invalide
                Console.WriteLine("ce nombre est invalid");
            else
            {
                solde -= minus; // soubstrait minus de solde
                Console.WriteLine("Ton solde est: " + solde + "$");
            }
        }
    }
}
