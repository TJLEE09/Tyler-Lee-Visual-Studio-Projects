﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool numberValid = false;
            bool numbersValid = false;
            bool numbersValid3 = false;
            int numcompte = 0;
            string nom;
            string prenom;
            int add;
            int minus;

            Console.WriteLine("--------------------------{0} Bienvenu a la banque de Tyler {0}--------------------------", Environment.NewLine); // diviser le texte

            Console.WriteLine("entrez votre nom"); // demander leur nom
            nom = Console.ReadLine(); // nom = readline

            Console.WriteLine("entrez votre prenom"); // demander leur prenom
            prenom = Console.ReadLine(); // prenom = readline

            while (!numberValid) // while number valid 
            {
                Console.WriteLine("entrez votre numero de compte"); // demander le numero de compte
                string saisie = Console.ReadLine(); // saisie = readline
                numberValid = int.TryParse(saisie, out numcompte); // tryparse en int 
                if (numberValid) // if number valid 
                {
                    Console.WriteLine("Ton compte est: " + numcompte); // dire leur nombre de compte
                }
                else
                {
                    Console.WriteLine("Le numéro que vous avez saisi n'est pas valide"); // le nombre n<est pas valid 
                }
            }

            Compte compte = new Compte(prenom, nom, numcompte, 500); // cree un nouveaux compte 

            Console.Clear(); // console clear 

            while (true) // while loop
            {
                Console.WriteLine("----------------{0} Info de compte {0}----------------", Environment.NewLine); // diviser le texte
                compte.Info();

                Console.WriteLine("Voudriez-vous ajouter de l'argent ? : 1"); // demander si il veux ajouter de largent
                Console.WriteLine("Voudriez-vous retirer de l'argent ? : 2"); // demander si il veux retirer de l'argent
                Console.WriteLine("Voudrais-tu arrêter ? : 3"); // demander si il veux arreter le programe

                string awnser = Console.ReadLine(); // readline 

                if (awnser == "1") // if awnser = 1
                { 
                    while (!numbersValid) // while loop
                    {
                        Console.WriteLine("combien d'argent souhaiteriez-vous ajouter"); // combien d'argent souhaiteriez-vous ajouter 
                        string saisie = Console.ReadLine();// if numbers valid 
                        numbersValid = int.TryParse(saisie, out add); // tryparse en int 
                        if (numbersValid) // if numbers valid 
                        {
                            Console.WriteLine("tu as ajouté " + add + "$"); // afficher le montant
                        }
                        else
                        {
                            Console.WriteLine("Le numéro que vous avez saisi n'est pas valide");// le numero nes pas valide
                        }
                        compte.Virement(add);//afficher virement 
                        Console.Clear(); //clear console
                        compte.Info();//afficher info 
                    }   
                }

                if (awnser == "2")
                {
                    while (!numbersValid3)
                    {
                        Console.WriteLine("combien d'argent souhaiteriez-vous retirer"); // combien d'argent souhaiteriez-vous retirer
                        string saisie = Console.ReadLine();// if numbers valid 
                        numbersValid3 = int.TryParse(saisie, out minus);// tryparse en int 
                        if (numbersValid3)// if numbers valid 
                        {
                            Console.WriteLine("tu as soustrait " + minus + "$");// afficher le montant
                        }
                        else
                        {
                            Console.WriteLine("Le numéro que vous avez saisi n'est pas valide"); // le numero nes pas valide 
                        }
                        compte.Retrait(minus); //afficher retrait 
                        Console.Clear();// clear console
                        compte.Info(); //afficher info 
                    }
                }

                if (awnser == "3") // if awnser 3
                    break; // end code

                else
                {
                    Console.WriteLine("Le numéro que vous avez saisi n'est pas valide"); // le numero est pas valide 
                    Console.Clear(); // clear 
                }
            }

        }
    }
}
