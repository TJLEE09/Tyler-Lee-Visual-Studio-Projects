﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evaluation_5
{
    public partial class RGB : Form
    {
        public RGB()
        {
            InitializeComponent();
        }

        private void rgbPanel_Paint(object sender, PaintEventArgs e)
        {  
        }

        private void redScrollBar_Scroll(object sender, ScrollEventArgs e)
        {
            displayRedLabel.Text = redScrollBar.Value.ToString();
            rgbPanel.BackColor = Color.FromArgb(redScrollBar.Value, greenScrollBar.Value, blueScrollBar.Value);
        }

        private void greenScrollBar_Scroll(object sender, ScrollEventArgs e)
        {
            displayGreenLabel.Text = greenScrollBar.Value.ToString();
            rgbPanel.BackColor = Color.FromArgb(redScrollBar.Value, greenScrollBar.Value, blueScrollBar.Value);
        }

        private void blueScrollBar_Scroll(object sender, ScrollEventArgs e)
        {
            displayBlueLabel.Text = blueScrollBar.Value.ToString();
            rgbPanel.BackColor = Color.FromArgb(redScrollBar.Value, greenScrollBar.Value, blueScrollBar.Value);
        }
    }
}
