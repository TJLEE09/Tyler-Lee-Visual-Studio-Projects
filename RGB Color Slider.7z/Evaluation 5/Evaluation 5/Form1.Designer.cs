﻿
namespace Evaluation_5
{
    partial class RGB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.redLabel = new System.Windows.Forms.Label();
            this.redScrollBar = new System.Windows.Forms.HScrollBar();
            this.displayRedLabel = new System.Windows.Forms.Label();
            this.rgbPanel = new System.Windows.Forms.Panel();
            this.displayGreenLabel = new System.Windows.Forms.Label();
            this.greenScrollBar = new System.Windows.Forms.HScrollBar();
            this.greenLabel = new System.Windows.Forms.Label();
            this.displayBlueLabel = new System.Windows.Forms.Label();
            this.blueScrollBar = new System.Windows.Forms.HScrollBar();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // redLabel
            // 
            this.redLabel.AutoSize = true;
            this.redLabel.BackColor = System.Drawing.Color.Red;
            this.redLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.redLabel.Location = new System.Drawing.Point(35, 22);
            this.redLabel.Name = "redLabel";
            this.redLabel.Size = new System.Drawing.Size(69, 25);
            this.redLabel.TabIndex = 0;
            this.redLabel.Text = "Rouge";
            // 
            // redScrollBar
            // 
            this.redScrollBar.LargeChange = 1;
            this.redScrollBar.Location = new System.Drawing.Point(121, 21);
            this.redScrollBar.Maximum = 255;
            this.redScrollBar.Name = "redScrollBar";
            this.redScrollBar.Size = new System.Drawing.Size(381, 26);
            this.redScrollBar.TabIndex = 1;
            this.redScrollBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.redScrollBar_Scroll);
            // 
            // displayRedLabel
            // 
            this.displayRedLabel.AutoSize = true;
            this.displayRedLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayRedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayRedLabel.Location = new System.Drawing.Point(533, 22);
            this.displayRedLabel.Name = "displayRedLabel";
            this.displayRedLabel.Size = new System.Drawing.Size(35, 27);
            this.displayRedLabel.TabIndex = 2;
            this.displayRedLabel.Text = "---";
            // 
            // rgbPanel
            // 
            this.rgbPanel.Location = new System.Drawing.Point(615, 21);
            this.rgbPanel.Name = "rgbPanel";
            this.rgbPanel.Size = new System.Drawing.Size(127, 116);
            this.rgbPanel.TabIndex = 3;
            this.rgbPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.rgbPanel_Paint);
            // 
            // displayGreenLabel
            // 
            this.displayGreenLabel.AutoSize = true;
            this.displayGreenLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayGreenLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayGreenLabel.Location = new System.Drawing.Point(533, 67);
            this.displayGreenLabel.Name = "displayGreenLabel";
            this.displayGreenLabel.Size = new System.Drawing.Size(35, 27);
            this.displayGreenLabel.TabIndex = 6;
            this.displayGreenLabel.Text = "---";
            // 
            // greenScrollBar
            // 
            this.greenScrollBar.LargeChange = 1;
            this.greenScrollBar.Location = new System.Drawing.Point(121, 66);
            this.greenScrollBar.Maximum = 255;
            this.greenScrollBar.Name = "greenScrollBar";
            this.greenScrollBar.Size = new System.Drawing.Size(381, 26);
            this.greenScrollBar.TabIndex = 5;
            this.greenScrollBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.greenScrollBar_Scroll);
            // 
            // greenLabel
            // 
            this.greenLabel.AutoSize = true;
            this.greenLabel.BackColor = System.Drawing.Color.Green;
            this.greenLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.greenLabel.Location = new System.Drawing.Point(35, 67);
            this.greenLabel.Name = "greenLabel";
            this.greenLabel.Size = new System.Drawing.Size(48, 25);
            this.greenLabel.TabIndex = 4;
            this.greenLabel.Text = "Vert";
            // 
            // displayBlueLabel
            // 
            this.displayBlueLabel.AutoSize = true;
            this.displayBlueLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayBlueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayBlueLabel.Location = new System.Drawing.Point(533, 113);
            this.displayBlueLabel.Name = "displayBlueLabel";
            this.displayBlueLabel.Size = new System.Drawing.Size(35, 27);
            this.displayBlueLabel.TabIndex = 9;
            this.displayBlueLabel.Text = "---";
            // 
            // blueScrollBar
            // 
            this.blueScrollBar.LargeChange = 1;
            this.blueScrollBar.Location = new System.Drawing.Point(121, 112);
            this.blueScrollBar.Maximum = 255;
            this.blueScrollBar.Name = "blueScrollBar";
            this.blueScrollBar.Size = new System.Drawing.Size(381, 26);
            this.blueScrollBar.TabIndex = 8;
            this.blueScrollBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.blueScrollBar_Scroll);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Blue;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(35, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Bleu";
            // 
            // RGB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 153);
            this.Controls.Add(this.displayBlueLabel);
            this.Controls.Add(this.blueScrollBar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.displayGreenLabel);
            this.Controls.Add(this.greenScrollBar);
            this.Controls.Add(this.greenLabel);
            this.Controls.Add(this.rgbPanel);
            this.Controls.Add(this.displayRedLabel);
            this.Controls.Add(this.redScrollBar);
            this.Controls.Add(this.redLabel);
            this.MaximumSize = new System.Drawing.Size(800, 200);
            this.MinimumSize = new System.Drawing.Size(800, 200);
            this.Name = "RGB";
            this.Text = "RGB/RVB";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label redLabel;
        private System.Windows.Forms.HScrollBar redScrollBar;
        private System.Windows.Forms.Label displayRedLabel;
        private System.Windows.Forms.Panel rgbPanel;
        private System.Windows.Forms.Label displayGreenLabel;
        private System.Windows.Forms.HScrollBar greenScrollBar;
        private System.Windows.Forms.Label greenLabel;
        private System.Windows.Forms.Label displayBlueLabel;
        private System.Windows.Forms.HScrollBar blueScrollBar;
        private System.Windows.Forms.Label label4;
    }
}

